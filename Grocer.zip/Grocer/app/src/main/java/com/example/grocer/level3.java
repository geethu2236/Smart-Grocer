package com.example.grocer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class level3 extends AppCompatActivity {
    private ImageView levelIndicator;
    private TextView levelDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level3);
        levelIndicator = findViewById(R.id.levelIndicator);
        levelDetails = findViewById(R.id.levelDetails);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users/9345894997/Level3");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int level1 = dataSnapshot.getValue(Integer.class);
                    updateUI(level1);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors.
            }
        });
    }

    private void updateUI(int level) {
        if (level <= 250) {
            levelIndicator.setImageResource(R.drawable.empty_container);
        } else if (level <= 500) {
            levelIndicator.setImageResource(R.drawable.quarter_full_container);
        } else if (level <= 750) {
            levelIndicator.setImageResource(R.drawable.half_full_container);
        } else if (level < 1000) {
            levelIndicator.setImageResource(R.drawable.three_quarters_full_container);
        } else {
            levelIndicator.setImageResource(R.drawable.full_container);
        }
        levelDetails.setText("Salt Level: " + level );
    }
}