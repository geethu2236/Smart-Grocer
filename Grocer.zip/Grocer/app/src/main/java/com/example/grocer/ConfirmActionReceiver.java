package com.example.grocer;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class ConfirmActionReceiver extends BroadcastReceiver {

    private static final String ACCOUNT_SID = "ACb30bb9f2eca211ecf7ed072ac2156269"; // Twilio Account SID
    private static final String AUTH_TOKEN = "68e9e37e4e24bda9d39c8b5a0bc69348"; // Twilio Auth Token
    private static final String TWILIO_NUMBER = "+14155238886"; // Twilio WhatsApp Number
    private static final String TAG = "ConfirmActionReceiver";

    private String storeWhatsAppNumber;
    private String storeName;
    private String address;

    @Override
    public void onReceive(Context context, Intent intent) {
        // Validate received data
        String provisionName = intent.getStringExtra("provisionName");
        int provisionLevel = intent.getIntExtra("provisionLevel", 0);

        if (provisionName == null || provisionLevel <= 0) {
            Log.e(TAG, "Invalid provision data received.");
            return;
        }

        // Log the received data for debugging
        Log.d(TAG, "Provision Name: " + provisionName);
        Log.d(TAG, "Provision Level: " + provisionLevel);

        // Fetch store's WhatsApp number and address from Firebase
        String userId = "9345894997"; // Replace with dynamic userId if needed
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        ref.get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {
                storeWhatsAppNumber = dataSnapshot.child("StoreWhatsapp").getValue(String.class);
                storeName = dataSnapshot.child("StoreName").getValue(String.class);
                address = dataSnapshot.child("Address").getValue(String.class);

                // Validate retrieved data
                if (storeWhatsAppNumber == null || storeWhatsAppNumber.isEmpty() || storeName == null || storeName.isEmpty() || address == null || address.isEmpty()) {
                    Log.e(TAG, "Store details are missing.");
                    return;
                }

                // Message content
                String message = "Hi " + storeName + ", I need " + provisionName +
                        " in quantity " + provisionLevel + " grams at this address: " + address;

                // Send WhatsApp message using Twilio
                sendWhatsAppMessage(storeWhatsAppNumber, message);

            } else {
                Log.e(TAG, "Firebase data snapshot is empty.");
            }
        }).addOnFailureListener(e -> Log.e(TAG, "Error fetching data from Firebase", e));
    }

    private void sendWhatsAppMessage(String toNumber, String message) {
        // Configure OkHttpClient with timeouts
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();

        // Twilio API URL
        String url = "https://api.twilio.com/2010-04-01/Accounts/" + ACCOUNT_SID + "/Messages.json";

        // Build the request body
        RequestBody body = new FormBody.Builder()
                .add("From", "whatsapp:" + TWILIO_NUMBER)
                .add("To", "whatsapp:" + toNumber)
                .add("Body", message)
                .build();

        // Create the request
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("Authorization", okhttp3.Credentials.basic(ACCOUNT_SID, AUTH_TOKEN))
                .build();

        // Make the API call
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e(TAG, "Failed to send message: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d(TAG, "Message sent successfully!");
                } else {
                    Log.e(TAG, "Failed to send message: " + response.message());
                }
            }
        });
    }
}
