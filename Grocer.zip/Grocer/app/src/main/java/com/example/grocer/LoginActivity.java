package com.example.grocer;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class LoginActivity extends AppCompatActivity {
    private DatabaseReference databaseReference;
    private EditText etMobile, etOtp;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etMobile = findViewById(R.id.et_login_mobile);
        etOtp = findViewById(R.id.et_login_otp);
        btnLogin = findViewById(R.id.btn_login);
        TextView tvForgotOtp = findViewById(R.id.tv_forgot_otp);


        // Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        tvForgotOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,ForgotOtp.class);
                startActivity(intent);
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,provision_level.class);
                startActivity(intent);
            }
        });

        btnLogin.setOnClickListener(view -> {
            String mobileNumber = etMobile.getText().toString().trim();
            String enteredOtp = etOtp.getText().toString().trim();

            if (TextUtils.isEmpty(mobileNumber) || TextUtils.isEmpty(enteredOtp)) {
                Toast.makeText(LoginActivity.this, "Please enter mobile number and OTP.", Toast.LENGTH_SHORT).show();
            } else {
                verifyOtpFromFirebase(mobileNumber, enteredOtp);
            }
        });
    }

    // Function to retrieve OTP from Firebase and verify it
    private void verifyOtpFromFirebase(String mobileNumber, String enteredOtp) {
        // Retrieve OTP stored under 'Users' node in Firebase
        databaseReference.child(mobileNumber).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                // Extract OTP stored in Firebase
                String storedOtp = task.getResult().child("OTP").getValue(String.class);

                if (storedOtp != null && storedOtp.equals(enteredOtp)) {
                    Toast.makeText(LoginActivity.this, "OTP Verified Successfully!", Toast.LENGTH_SHORT).show();
                    loginUser(); // Proceed to login
                    Intent intent = new Intent(LoginActivity.this, provision_level.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(LoginActivity.this, "Invalid OTP, please try again.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(LoginActivity.this, "User not found or Firebase error.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    // Proceed to the next activity after successful login
    private void loginUser() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}