package com.example.grocer;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;

public class EditProvisionActivity extends AppCompatActivity {
    private TextView provisionNameTextView;
    private EditText quantityEditText;
    private Button confirmButton;

    private DatabaseReference databaseReference;
    private String provisionName;

    private static final String ACCOUNT_SID = "ACb30bb9f2eca211ecf7ed072ac2156269";
    private static final String AUTH_TOKEN = "68e9e37e4e24bda9d39c8b5a0bc69348";
    private static final String TWILIO_NUMBER = "+14155238886";
    private String storeWhatsAppNumber;
    private String storename;
    private String Address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_provision);

        // Initialize UI elements
        provisionNameTextView = findViewById(R.id.provisionNameTextView);
        quantityEditText = findViewById(R.id.quantityEditText);
        confirmButton = findViewById(R.id.confirmButton);

        // Get data passed from the previous activity
        provisionName = getIntent().getStringExtra("provisionName");

        // Set provision name
        provisionNameTextView.setText(provisionName);

        // Initialize Firebase reference
        String userId = "9345894997"; // Replace with dynamic userId if needed
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        fetchStoreWhatsAppNumber();
        fetchadress();
        fetchstorename();

        confirmButton.setOnClickListener(v -> {
            // Get the entered quantity and send a WhatsApp message
            String input = quantityEditText.getText().toString().trim();
            if (input.isEmpty()) {
                Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int enteredQuantity = Integer.parseInt(input);

            if (storeWhatsAppNumber != null && !storeWhatsAppNumber.isEmpty()) {
                sendWhatsAppMessage(storeWhatsAppNumber, "Hi " + storename+ "I need " + provisionName  + " in" + enteredQuantity + " grams "+"in this address " + Address );
            } else {
                Log.e("EditProvision", "Store WhatsApp number is not available");
            }

            Toast.makeText(this, "WhatsApp message sent successfully", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void fetchStoreWhatsAppNumber() {
        databaseReference.addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    storeWhatsAppNumber = snapshot.child("StoreWhatsapp").getValue(String.class);
                    if (storeWhatsAppNumber == null || storeWhatsAppNumber.isEmpty()) {
                        Log.e("Firebase", "Store WhatsApp number is missing");
                    }
                } else {
                    Log.e("Firebase", "User data does not exist");
                }
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                Log.e("Firebase", "Database error: " + error.getMessage());
            }
        });
    }

    private void fetchadress() {
        databaseReference.addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Address = snapshot.child("Address").getValue(String.class);
                    if (Address == null || Address.isEmpty()) {
                        Log.e("Firebase", "Address is missing");
                    }
                } else {
                    Log.e("Firebase", "User data does not exist");
                }
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                Log.e("Firebase", "Database error: " + error.getMessage());
            }
        });
    }
    private void fetchstorename() {
        databaseReference.addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    storename = snapshot.child("StoreName").getValue(String.class);
                    if (storename == null || storename.isEmpty()) {
                        Log.e("Firebase", "store name is missing");
                    }
                } else {
                    Log.e("Firebase", "User data does not exist");
                }
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                Log.e("Firebase", "Database error: " + error.getMessage());
            }
        });
    }
    private void sendWhatsAppMessage(String toNumber, String message) {
        OkHttpClient client = new OkHttpClient();

        String url = "https://api.twilio.com/2010-04-01/Accounts/" + ACCOUNT_SID + "/Messages.json";

        RequestBody formBody = new FormBody.Builder()
                .add("From", "whatsapp:" + TWILIO_NUMBER)
                .add("To", "whatsapp:" + toNumber)
                .add("Body", message)
                .build();

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", okhttp3.Credentials.basic(ACCOUNT_SID, AUTH_TOKEN))
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("Twilio", "Failed to send message: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d("Twilio", "Message sent successfully");
                } else {
                    Log.e("Twilio", "Failed to send message. Response: " + response.message());
                }
            }
        });
    }
}
