package com.example.grocer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Credentials;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ForgotOtp extends AppCompatActivity {
    EditText etMobile;
    Button btnGenerateOTP;
    TextView tvBackToLogin;
    DatabaseReference dbRef;
    String otp; // To store generated OTP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_otp);

        // Initialize Firebase and views
        dbRef = FirebaseDatabase.getInstance().getReference("Users");
        etMobile = findViewById(R.id.et_mobile);
        btnGenerateOTP = findViewById(R.id.btn_generate_otp);
        tvBackToLogin = findViewById(R.id.tv_back_to_login);

        // Back to login functionality
        tvBackToLogin.setOnClickListener(v -> {
            Intent intent = new Intent(ForgotOtp.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        // Generate OTP button functionality
        btnGenerateOTP.setOnClickListener(v -> {
            String enteredMobile = etMobile.getText().toString();

            if (enteredMobile.isEmpty()) {
                Toast.makeText(this, "Please enter your mobile number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check Firebase for matching mobile number
            dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    boolean mobileExists = false;

                    // Iterate through all Users to check for matching mobile numbers
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String registeredMobile = userSnapshot.child("Mobile").getValue(String.class);

                        if (registeredMobile != null && registeredMobile.equals(enteredMobile)) {
                            // Mobile number matches, generate OTP
                            mobileExists = true;
                            otp = String.valueOf(new Random().nextInt(899999) + 100000); // Generate 6-digit OTP

                            // Update OTP in Firebase
                            HashMap<String, Object> updateOtp = new HashMap<>();
                            updateOtp.put("OTP", otp);
                            dbRef.child(enteredMobile).updateChildren(updateOtp);

                            // Send OTP via Twilio
                            sendOTPSMS(enteredMobile, otp);
                            break;
                        }
                    }

                    if (!mobileExists) {
                        // Mobile number not found
                        Toast.makeText(ForgotOtp.this, "Mobile number not registered", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(ForgotOtp.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // Method to send OTP via Twilio SMS API
    private void sendOTPSMS(String mobile, String otp) {
        String ACCOUNT_SID = "ACb30bb9f2eca211ecf7ed072ac2156269";  // Replace with your Twilio Account SID
        String AUTH_TOKEN = "68e9e37e4e24bda9d39c8b5a0bc69348";    // Replace with your Twilio Auth Token
        String TWILIO_NUMBER = "+17753642218";     // Replace with your Twilio phone number

        OkHttpClient client = new OkHttpClient();
        String message = "Your OTP for password reset is: " + otp;

        // Twilio API URL
        String url = "https://api.twilio.com/2010-04-01/Accounts/" + ACCOUNT_SID + "/Messages.json";

        RequestBody body = new FormBody.Builder()
                .add("To", "+91" + mobile)  // User's mobile number (add country code)
                .add("From", TWILIO_NUMBER) // Twilio phone number
                .add("Body", message)       // Message content
                .build();

        // Authorization header
        String credentials = Credentials.basic(ACCOUNT_SID, AUTH_TOKEN);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .header("Authorization", credentials)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(ForgotOtp.this, "Failed to send OTP", Toast.LENGTH_SHORT).show()
                );
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    runOnUiThread(() ->
                            Toast.makeText(ForgotOtp.this, "OTP sent successfully!", Toast.LENGTH_SHORT).show()
                    );
                } else {
                    runOnUiThread(() ->
                            Toast.makeText(ForgotOtp.this, "Error sending OTP", Toast.LENGTH_SHORT).show()
                    );
                }
            }
        });
    }
}
