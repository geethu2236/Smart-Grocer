package com.example.grocer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class provision_level extends AppCompatActivity {
    Button btnLevel1, btnLevel2, btnLevel3, btnLevel4, btnLevel5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provision_level);

        // Initialize buttons
        btnLevel1 = findViewById(R.id.btn_level1);
        btnLevel2 = findViewById(R.id.btn_level2);
        btnLevel3 = findViewById(R.id.btn_level3);
        btnLevel4 = findViewById(R.id.btn_level4);
        btnLevel5 = findViewById(R.id.btn_level5);

        // Set onClick listeners for each button
        btnLevel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(provision_level.this, level1.class);
                startActivity(intent);
            }
        });

        btnLevel2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(provision_level.this, level2.class);
                startActivity(intent);
            }
        });

        btnLevel3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(provision_level.this, level3.class);
                startActivity(intent);
            }
        });

        btnLevel4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(provision_level.this, level4.class);
                startActivity(intent);
            }
        });

        btnLevel5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(provision_level.this, level5.class);
                startActivity(intent);
            }
        });
    }
}
