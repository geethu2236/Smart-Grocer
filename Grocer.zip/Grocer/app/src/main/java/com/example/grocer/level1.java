package com.example.grocer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;

public class level1 extends AppCompatActivity {
    private ImageView levelIndicator;
    private TextView levelDetails;
    private static final String CHANNEL_ID = "ProvisionChannel";
    private static final int NOTIFICATION_ID = 101;

    private DatabaseReference databaseReference;
    private String storeWhatsAppNumber;
    private int lastNotifiedLevel = -1;

    private static final String ACCOUNT_SID = "ACb30bb9f2eca211ecf7ed072ac2156269";
    private static final String AUTH_TOKEN = "68e9e37e4e24bda9d39c8b5a0bc69348";
    private static final String TWILIO_NUMBER = "+14155238886";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level1);

        levelIndicator = findViewById(R.id.levelIndicator);
        levelDetails = findViewById(R.id.levelDetails);

        // Fetch user ID and initialize Firebase reference
        String userId = getIntent().getStringExtra("userId");
        if (userId == null) {
            userId = "9345894997"; // Default for testing
        }
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Fetch store WhatsApp number from Firebase
        fetchStoreWhatsAppNumber();

        // Monitor provision level and trigger notifications
        databaseReference.child("Level1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Integer level1 = snapshot.getValue(Integer.class);
                    if (level1 != null) {
                        updateUI(level1);
                        if (level1 <= 250) {
                            showNotification("Rice", level1);
                        }
                    }
                } else {
                    Log.e("Firebase", "Level1 data does not exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Database error: " + error.getMessage());
            }
        });

        createNotificationChannel();
        requestNotificationPermission();
    }

    private void fetchStoreWhatsAppNumber() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    storeWhatsAppNumber = snapshot.child("StoreWhatsapp").getValue(String.class);
                    if (storeWhatsAppNumber == null || storeWhatsAppNumber.isEmpty()) {
                        Log.e("Firebase", "Store WhatsApp number is missing");
                    }
                } else {
                    Log.e("Firebase", "User data does not exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Database error: " + error.getMessage());
            }
        });
    }

    private void updateUI(int level) {
        int imageResource;
        if (level <= 250) {
            imageResource = R.drawable.empty_container;
        } else if (level <= 500) {
            imageResource = R.drawable.quarter_full_container;
        } else if (level <= 750) {
            imageResource = R.drawable.half_full_container;
        } else if (level < 1000) {
            imageResource = R.drawable.three_quarters_full_container;
        } else {
            imageResource = R.drawable.full_container;
        }
        levelIndicator.setImageResource(imageResource);
        levelDetails.setText("Rice Level: " + level + " grams");
    }

    private void showNotification(String provisionName, int provisionLevel) {
        if (provisionLevel <= 250 && provisionLevel != lastNotifiedLevel) {
            lastNotifiedLevel = provisionLevel;

            Intent editIntent = new Intent(this, EditProvisionActivity.class);
            editIntent.putExtra("provisionName", provisionName);
            editIntent.putExtra("provisionLevel", provisionLevel);

            PendingIntent editPendingIntent = PendingIntent.getActivity(
                    this, 0, editIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent confirmIntent = new Intent(this, ConfirmActionReceiver.class);
            confirmIntent.putExtra("provisionName", provisionName);
            confirmIntent.putExtra("provisionLevel", 1000);

            PendingIntent confirmPendingIntent = PendingIntent.getBroadcast(
                    this, 0, confirmIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("Low Stock Alert")
                    .setContentText(provisionName + " level is below " + provisionLevel + " grams!")
                    .addAction(R.drawable.ic_edit, "Edit", editPendingIntent)
                    .addAction(R.drawable.ic_confirm, "Confirm", confirmPendingIntent)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true);

            NotificationManagerCompat manager = NotificationManagerCompat.from(this);
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            manager.notify(NOTIFICATION_ID, builder.build());
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Provision Alerts", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Alerts for provision levels");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    public void sendWhatsAppMessage(String toNumber, String message) {
        OkHttpClient client = new OkHttpClient();

        String url = "https://api.twilio.com/2010-04-01/Accounts/" + ACCOUNT_SID + "/Messages.json";

        RequestBody formBody = new FormBody.Builder()
                .add("From", "whatsapp:" + TWILIO_NUMBER)
                .add("To", "whatsapp:" + toNumber)
                .add("Body", message)
                .build();

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", okhttp3.Credentials.basic(ACCOUNT_SID, AUTH_TOKEN))
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("Twilio", "Failed to send message: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d("Twilio", "Message sent successfully");
                } else {
                    Log.e("Twilio", "Failed to send message. Response: " + response.message());
                }
            }
        });
    }
}
